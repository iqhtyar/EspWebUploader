import binascii
import serial
import time

def convert_to_binary(file_path):
    with open(file_path, 'r') as file:
        text_content = file.read()
        binary_content = binascii.hexlify(text_content.encode())
    return binary_content

def upload_to_esp8266(serial_port, binary_content):
    with serial.Serial(serial_port, baudrate=115200, timeout=5) as ser:
        time.sleep(2)  # Delay untuk memberi waktu ESP8266 untuk booting

        ser.write(binary_content)
        print("Upload selesai")

if __name__ == "__main__":
    file_path = "coding.txt"
    serial_port = "/dev/ttyUSB0"  # Sesuaikan dengan port serial ESP8266

    binary_content = convert_to_binary(file_path)
    upload_to_esp8266(serial_port, binary_content)
