import serial
import binascii

def convert_to_bin(text):
  return binascii.unhexlify(text.replace(" ", ""))

def upload_to_serial(data, port, baudrate):
  with serial.Serial(port, baudrate) as ser:
    ser.write(data)

if __name__ == "__main__":
  # Buka file teks
  with open("coding.txt", "r") as f:
    text = f.read()

  # Konversi file teks ke format biner
  data = convert_to_bin(text)

  # Upload data ke serial port
  upload_to_serial(data, "COM3", 9600)
