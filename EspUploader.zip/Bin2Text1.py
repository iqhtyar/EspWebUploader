import binascii

def convert_bin_to_text(bin_data):
  return binascii.hexlify(bin_data).decode("utf-8").replace(" ", "")

def convert_bin_to_file(bin_data, filename):
  with open(filename, "w") as f:
    f.write(convert_bin_to_text(bin_data))

if __name__ == "__main__":
  # Buka file bin
  with open("code.bin", "rb") as f:
    bin_data = f.read()

  # Konversi file bin ke format teks
  text = convert_bin_to_text(bin_data)

  # Konversi file bin ke file txt
  convert_bin_to_file(text, "code.txt")
